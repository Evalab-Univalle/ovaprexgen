/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jfxtras.app;

import com.sun.deploy.net.cookie.CookieHandler;
import com.sun.deploy.net.offline.OfflineHandler;
import com.sun.deploy.net.proxy.BrowserProxyConfig;
import com.sun.deploy.net.proxy.ProxyHandler;
import com.sun.deploy.security.BrowserAuthenticator;
import com.sun.deploy.security.CertStore;
import com.sun.deploy.security.CredentialManager;
import com.sun.deploy.services.Service;
import java.security.KeyStore;
import java.security.SecureRandom;

/**
 * @author Stephen Chin
 */
class XService implements Service {
    private final Service originalService;

    public XService(Service originalService) {
        this.originalService = originalService;
    }

    @Override
    public CookieHandler getCookieHandler() {
        return originalService.getCookieHandler();
    }

    @Override
    public BrowserProxyConfig getProxyConfig() {
        return originalService.getProxyConfig();
    }

    @Override
    public ProxyHandler getSystemProxyHandler() {
        return originalService.getSystemProxyHandler();
    }

    @Override
    public ProxyHandler getAutoProxyHandler() {
        return originalService.getAutoProxyHandler();
    }

    @Override
    public ProxyHandler getBrowserProxyHandler() {
        return originalService.getBrowserProxyHandler();
    }

    @Override
    public CertStore getBrowserSigningRootCertStore() {
        return originalService.getBrowserSigningRootCertStore();
    }

    @Override
    public CertStore getBrowserSSLRootCertStore() {
        return originalService.getBrowserSSLRootCertStore();
    }

    @Override
    public CertStore getBrowserTrustedCertStore() {
        return originalService.getBrowserTrustedCertStore();
    }

    @Override
    public KeyStore getBrowserClientAuthKeyStore() {
        return originalService.getBrowserClientAuthKeyStore();
    }

    @Override
    public BrowserAuthenticator getBrowserAuthenticator() {
        return originalService.getBrowserAuthenticator();
    }

    @Override
    public CredentialManager getCredentialManager() {
        return originalService.getCredentialManager();
    }

    @Override
    public SecureRandom getSecureRandom() {
        SecureRandom random = originalService.getSecureRandom();
        return random == null ? new SecureRandom() : random;
    }

    @Override
    public boolean isIExplorer() {
        return originalService.isIExplorer();
    }

    @Override
    public boolean isNetscape() {
        return originalService.isNetscape();
    }

    @Override
    public OfflineHandler getOfflineHandler() {
        return originalService.getOfflineHandler();
    }

}
