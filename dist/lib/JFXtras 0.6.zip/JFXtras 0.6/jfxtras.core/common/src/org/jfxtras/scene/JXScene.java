/*
 * Copyright (c) 2008-2010, JFXtras Group
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of JFXtras nor the names of its contributors may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package org.jfxtras.scene;

import java.awt.BorderLayout;
import javax.swing.JComponent;

import com.sun.javafx.tk.swing.SwingScene;
import java.util.Map;
import javafx.reflect.FXClassType;
import javafx.reflect.FXContext;
import javafx.reflect.FXFunctionMember;
import javafx.reflect.FXLocal;
import javafx.reflect.FXLocal.ObjectValue;
import javafx.reflect.FXObjectValue;
import javafx.scene.Scene;

/**
 * A Java class that allows embedding a javafx scene in java/swing.
 * It allows communication between the swing and javafx side.
 *
 * This class was originally created by Richard Bair and Jasper Potts and re-implemented for version javafx1.2
 * For more examples and documentation check out this blog post: http://blogs.sun.com/javafx/entry/how_to_use_javafx_in
 *
 * Example (Without Generic's):
 * @example
 * <code>
 *  import org.jfxtras.scene.JXScene;
 *
 *  public class TheFrame extends javax.swing.JFrame {
 *
 *      public TheFrame() {
 *          JXScene jxScene = new JXScene();
 *          jxScene.setScene("com.sun.test.MyScene"); // the name of your main JavaFX class
 *          add(jxScene); // add the scene your swing scene
 *          Printable printable = (Printable) jxScene.getScriptObject(); // The JavaFX Scene extends Printable (Printable is just an example, not part of the API)
 *          printable.print("calling javafx from the swing side");
 *      }
 *      public static void main(String args[]) {
 *         java.awt.EventQueue.invokeLater(new Runnable() {
 *             public void run() {
 *                 new TheFrame().setVisible(true);
 *             }
 *         });
 *      }
 *  }
 *  </code>
 *  @endexample
 *  <p>To run this, the jar files in the JavaFX SDK lib/shared and lib/desktop
 *  must be included in the java CLASSPATH.
 * @example
 * <code>
 * JAVAFX_HOME=/opt/javafx-1.2
 * SHARED=$JAVAFX_HOME/lib/shared
 * DESKTOP=$JAVAFX_HOME/lib/desktop

 * CP=dist/jfxtras.jar
 * CP=$CP:$SHARED/javafxrt.jar
 * CP=$CP:$SHARED/javafxc.jar
 * CP=$CP:$DESKTOP/decora-j2d-rsl.jar
 * CP=$CP:$DESKTOP/decora-ogl.jar
 * CP=$CP:$DESKTOP/decora-runtime.jar
 * CP=$CP:$DESKTOP/eula.jar
 * ...
 * java -cp $CP TheFrame
 * </code>
 * @endexample
 *
 * Generic's were addeded by Andrew Hughes. Typically you will be trying
 * to embed into a JComponent a JavaFX class that extends Scene and implement's
 * a java interface.
 *
 * <code>
 * //Example Java Interface
 * public interface Talker {
 *     public void talk(String message);
 * }
 *
 * //Example JavaFX Object, extends Scene and implements Talker (JavaInterface)
 * public class YourJavaFXScene extends Scene, Talker {
 *   public override function talk(msg:String):Void {...}
 * }
 *
 * //Example With Generics from Java Swing App. NOTE: the deferAction().
 *  import org.jfxtras.scene.JXScene;
 *
 *  public class TheFrame extends javax.swing.JFrame {
 *
 *      public TheFrame() {
 *          final JXScene<Talker> jxScene = new JXScene<Talker>();
 *          jxScene.setScene("com.yourproject.YourJavaFXScene"); // the name of your main JavaFX class
 *          add(jxScene); // add the scene your swing scene
 *          com.sun.javafx.runtime.Entry.deferAction( new Runnable() {
 *              public void run() {
 *                jxScene.getScene().talk("Hi There");//generics in action.
 *              }
 *          });
 *      }
 *      public static void main(String args[]) {
 *         java.awt.EventQueue.invokeLater(new Runnable() {
 *             public void run() {
 *                 new TheFrame().setVisible(true);
 *             }
 *         });
 *      }
 *  }
 * </code>
 *
 * @profile Desktop
 * @author Pedro Duque Vieira
 */
public class JXScene<T> extends JComponent {

    private T scene;

    public JXScene() {
        setLayout(new BorderLayout());
    }

    /**
     * Set the javafx scene class by className.
     * @param path the JavaFX object that extends javafx.scene.Scene.
     */
    public void setScene(String sceneClassName) {
        setScene((ObjectValue) FXLocal.getContext().findClass(sceneClassName).newInstance());
    }

    /**
     * Set the name of the javafx scene class
     * @param path the JavaFX object that extends javafx.scene.Scene.
     * @param initVars a keyed map of init's var's you want to set when creating
     * the script object.
     */
    public void setScene(String sceneClassName, Map<String, Object> initVars) {
        final FXObjectValue fxObjectValue = FXLocal.getContext().findClass(sceneClassName).allocate();
        for (String key : initVars.keySet()) {
            fxObjectValue.initVar(key, FXLocal.getContext().mirrorOf(initVars.get(key)));
        }
        setScene((ObjectValue) fxObjectValue.initialize());
    }

    /**
     * Method to reduce duplicated code only.
     * @param objectInstance FX objectInstance (scene)
     */
    private void setScene(final ObjectValue objectInstance) {
        scene = (T) objectInstance.asObject();
        add(sceneToJComponent((Scene) scene), BorderLayout.CENTER);
    }

    /**
     * This method wraps the Scene with a JComponent.
     * @param scene the JavaFX object that extends javafx.scene.Scene.
     * @return the javafx.scene.Scene wrapped by a JComponent.
     */
    private JComponent sceneToJComponent(Scene scene) {
        FXClassType sceneType = FXContext.getInstance().findClass("javafx.scene.Scene");
        ObjectValue obj = FXLocal.getContext().mirrorOf(scene);
        FXFunctionMember getPeer = sceneType.getFunction("impl_getPeer");
        FXLocal.ObjectValue peer = (ObjectValue) getPeer.invoke(obj);
        SwingScene swingScene = (SwingScene) peer.asObject();
        return swingScene.scenePanel;
    }

    /**
     * This method allows you to get the JavaFX Java Object. The JavaFX Java
     * Object typically implments a java interface T. This allows the JavaFX
     * Object to expose itself to the caller. Note, that JavaFX can extend
     * multiple Java intefaces, so there could be more than on type T on offer.
     * If this is the case you will need to cast the object yourself.
     * @return the javafx.scene.Scene java Object
     */
    public T getScene() {
        return scene;
    }
}